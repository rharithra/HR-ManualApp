package com.hrmanual;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrManualApplication {

    public static void main(String[] args) {
        SpringApplication.run(HrManualApplication.class, args);
    }
} 