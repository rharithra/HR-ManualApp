# Creating ZIP File for Upload

## Method 1: Select All Files
1. **Select all files and folders** in your project directory:
   - backend/
   - frontend/
   - .devcontainer/
   - README.md
   - DEPLOYMENT_GUIDE.md
   - setup.sh
   - railway.toml
   - render.yaml

2. **Right-click** → **"Send to Compressed folder"** (Windows) or **"Compress"** (Mac)

3. **Upload the ZIP file** to GitHub:
   - Go to your repository
   - Click "Add file" → "Upload files"
   - Drag the ZIP file
   - GitHub will automatically extract it

## Method 2: Command Line (if available)
```bash
# Create ZIP of entire project
zip -r hr-manual-app.zip . -x "*.git*" "node_modules/*" "target/*"

# Or using tar
tar -czf hr-manual-app.tar.gz --exclude='.git' --exclude='node_modules' --exclude='target' .
``` 